# Lantern service case — prototype v0.1

An editable, dimensioned enclosure for the **LCDWiki ES3C28P touchscreen Lantern**, with the existing microphone exposed at the upper front and through a short top-edge passage. A separate top-edge grille and internal space are reserved for a future external microphone. The oval black component is the speaker; it mounts inside the rear lid with its own grille.

**Status: CAD prototype, not yet physically printed or acoustically tested.** Battery and speaker dimensions came from the user's ruler measurements on 20 September 2026. Connector housings, speaker rim/diaphragm shape, battery wire exit, mic alignment and printer tolerances still require a fit check. Do not order an expensive finished print without the fit check.

## Files and what they mean

- `exports/print_first_front_fit_check.stl`: shallow 14 mm test piece. Check the board holes, screen and microphone alignment before the full case. This is a disposable fit gauge, not a fifth part of the finished enclosure.
- `exports/front_shell.stl`: green front frame and walls, open at the back.
- `exports/rear_lid.stl`: removable back with speaker grille and locating lip.
- `exports/battery_tray.stl`: removable separator and battery guides.
- `exports/speaker_retainer.stl`: ring securing the speaker to the lid.
- `exports/lantern_case.step`: editable solid CAD assembly for Fusion, FreeCAD, Onshape and similar tools.
- `exports/lantern_case.blend`: visual assembly, editable in Blender. Reference battery/screen/speaker objects are illustrative and must not be printed.
- `exports/assembled.png`, `rear.png`, `exploded.png`: renders of the actual generated geometry, with simplified electronics.
- `exports/preview.html`: self-contained rotatable 3D preview. Open this file in a browser; it works without an internet connection.
- `dimensions.json`: the measurements used by the model; all values are millimetres.
- `exports/validation.json`: solid, mesh and interference checks, including their limits.

**STL** is the shape file a print shop imports. **STEP** is the editable engineering model. The shop's **slicer** converts the STL into instructions for its printer. No Blender connection is needed to print these files. They are geometry, not printer-ready G-code.

Files ending `_assembly.stl` and `_reference.stl` support the preview only; do not add those to a print order. The four named print STLs are individually oriented with their lowest point at Z=0. STL does not embed units: import at **100% scale in millimetres**.

## Dimensions

| Item | Width × length × depth, mm | Basis |
|---|---|---|
| Finished enclosure | 88 × 112 × 39 | Prototype design with wiring/service space |
| ESP32 display PCB | 50 × 86 × 1.6 | Manufacturer drawing |
| Whole display/board stack | 50 × 86 × 10.6 | Manufacturer drawing |
| PCB mounting pattern | 42 × 78, four Ø3.2 holes | Manufacturer drawing |
| Battery | 59 × 91 × 5 | User ruler measurement; verify wire exit and pouch edges |
| Speaker envelope | 41 × 29 × 10 | User ruler measurement; verify rim and diaphragm clearance |
| Future mic space | 23 × 20 × 6 | Checked reserved volume, not a verified mount for a specific mic |
| Main walls / back plate | 2.4 | Design choice |
| Lid locating clearance | 0.35 per side | Starting value; tune after test print |

This is a serviceable prototype rather than a miniaturized production housing. The layered battery and 10 mm speaker drive the thickness. The speaker stays attached to the removable back; leave slack in its cable so opening the cover does not pull its connector off the board.

## Fasteners and soft parts

- Four **M3 × 8 mm machine screws** and four ordinary M3 hex nuts, approximately 5.5 mm across flats and 2.4 mm thick, to close the case. The modeled nut pockets are 5.8 mm across flats. Check screw head diameter is no larger than about 6 mm.
- Ten **2.5 × 6 mm plastic-thread/self-tapping screws**: four for the PCB, four for the battery tray and two for the speaker retainer. The model uses 2.1 mm pilot holes; verify the chosen screw and printed pilot on scrap first. Do not force a screw that splits a post.
- Four approximately **1 mm thick insulating washers** under the PCB screw heads, with a hole that fits the 2.5 mm screw. These limit screw penetration and protect the board.
- Thin nonconductive battery padding, modeled as **0.5 mm**, and two broad soft hook-and-loop straps around the tray and battery. Keep straps loose enough not to squeeze the pouch. No screw passes through the battery.
- Approximately **0.6 mm soft speaker gasket** around the speaker's rigid rim. Keep the diaphragm and grille unobstructed. The retainer geometry must be checked against the actual rear housing before tightening it.
- Optional thin open acoustic mesh behind the mic opening. Do not cover the sound port with solid tape, glue or a waterproof film.

Nut pockets open into the case. Insert the nuts before the lid and hold them in place while starting the screws. A small removable dab of adhesive on the outside edge of a nut can retain it; keep adhesive off the threads. No heat-set inserts are required for the four cover screws.

## First print and assembly

1. Ask a local FDM print shop to print **only `print_first_front_fit_check.stl` first**, at 100% scale in mm. PLA is sufficient for this dimensional gauge. Fit the unpowered board, check that the four mounts line up without bending it, and check that the bezel leaves the active screen clear. Check the microphone hole aligns with the board's MIC aperture.
2. Confirm the USB plug hood can reach the recessed socket through the opening. The board's USB port is recessed roughly 13 mm from the outside wall; the 18 mm opening is intentionally generous. Try your actual USB cable. BOOT/RESET and the SD card are accessed by removing the cover and, if necessary, the battery tray.
3. After the fit check, print the four final STL parts. PETG is the proposed working-case material; a PLA trial can check assembly. Starting settings: 0.4 mm nozzle, 0.2 mm layer height, four perimeters, five top/bottom layers and 20–30% infill. Ask the shop to inspect the USB opening and acoustic passage for bridge/support needs. These settings are a starting point, not a tested printer profile.
4. Disconnect USB and the battery before assembly. Seat the board on its four posts. The touchscreen faces the opening and the MIC end goes toward the small upper acoustic opening. Use the four PCB screws and insulating washers, tightening only until seated. Confirm no screw touches glass or a trace.
5. Route the battery and speaker cables before fitting the tray. Leave the upper antenna area and the microphone passage clear. If the tray interferes with a connector or wire bend, stop and adjust the model rather than crushing a cable.
6. Fit the removable battery tray using four screws. Add thin nonconductive padding, place the cell on the tray, and retain it with broad straps. Keep the pouch and its tabs away from posts, screw tips and sharp edges. The separator protects the cell from solder joints; it is not a sealed or fire-rated battery compartment.
7. Place the speaker in the rear-lid collar, facing the grille, with the thin gasket on its rigid rim. Fit the retaining ring with two screws. It should stop the speaker rattling without pushing on the diaphragm or squeezing the magnet assembly. Verify it clears the battery and straps when the cover closes.
8. Insert four M3 nuts into the shell pockets and close the lid with four M3 × 8 screws. The cover should sit flat with light pressure. If it needs force, reopen it and find the interference. For development, remove these four screws to reopen the case.
9. Compare a spoken command with the case open and closed. Listen for muffling, rattles or speaker feedback. Adjust the mic passage/gasket if needed before treating this as the final design.

The case is enclosed apart from the screen, USB opening and acoustic openings. It is **not waterproof**. A plastic case and an additional opening do not change the firmware's microphone selection.

## Validation and limitations

The build checks every final part is a valid single CAD solid, exports a watertight consistently wound STL, and checks that the separate printed parts do not overlap. It also checks against simplified board, glass, battery, speaker and USB envelopes. The model leaves clearance above the maximum component height in the manufacturer drawing.

These checks do not prove fit to every connector, cable, screw, LiPo pouch seam or speaker contour. Printer shrinkage, the actual battery terminal position, soldered wires and acoustic performance remain physical checks. The official board STEP was downloaded for reference; it is not redistributed in the case package.

## Rebuild

Use Python 3.11 with `requirements.txt`. From the repository root, the current workstation can run:

```powershell
& '.tools/lantern-cad-env/Scripts/python.exe' hardware/lantern-case/build_case.py
& 'C:\Program Files\Blender Foundation\Blender 5.0\blender.exe' --background --factory-startup --python hardware/lantern-case/render_preview.py
```

Edit `dimensions.json` to change measured component dimensions. Several mounting coordinates and port details in `build_case.py` are board-specific; replacing the board requires reviewing these, not just changing width and length.

Assembly coordinates: the front exterior is Z=0, +Z points toward the removable back, and +Y is the microphone end. +X is to the right when viewing the rear, so the front-facing MIC aperture is at X=-15.

## Sources

- [LCDWiki ES3C28P dimension drawing](https://www.lcdwiki.com/res/ES3C28P/ES3C28P_Size.pdf)
- [LCDWiki board documentation and manufacturer 3D download](https://www.lcdwiki.com/2.8inch_ESP32-S3_Display)
- [Prusa guidance on designing for printing](https://help.prusa3d.com/article/modeling-with-3d-printing-in-mind_164135)
- [Prusa PETG material guide](https://help.prusa3d.com/article/petg_2059)
